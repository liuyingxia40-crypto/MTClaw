# AIBOOK复现步骤

1. 设置密钥：export DEEPSEEK_API_KEY="你的密钥"
2. 安装：./install.sh
3. 验收：hicool-energy smoke
4. 查看状态：hicool-energy status

通过标准：自然语言基线结果4/4通过。
