# HICOOL 能碳智能工作站

## 功能
系统根据自然语言自动选择：
- 能碳诊断报告 Subagent
- 电费账单稽核 Subagent
- 节能改造项目管理 Subagent
- 碳资产运营 Subagent

快速路由使用 DeepSeek Flash，复杂任务使用 DeepSeek Pro。

## 安装
export DEEPSEEK_API_KEY="你的DeepSeek API Key"
chmod +x install.sh
./install.sh

## 使用
hicool-energy

## 验收
hicool-energy smoke
