#!/bin/bash
set -euo pipefail

PYTHON_FILE="$HOME/moor/MTClaw/vertical_subagents/energy_carbon_delivery_subagent.py"

error_exit() {
    jq -n --arg error "$1" '{
        "result": "error",
        "subagent": "energy_carbon_delivery_subagent",
        "error": $error
    }'
    exit 1
}

if [ ! -f "$PYTHON_FILE" ]; then
    error_exit "找不到能碳诊断与报告交付程序：$PYTHON_FILE"
fi

INPUT=$(cat)

if ! printf '%s' "$INPUT" | jq empty >/dev/null 2>&1; then
    error_exit "输入不是有效JSON"
fi

OUTPUT=$(printf '%s' "$INPUT" | python3 "$PYTHON_FILE") || {
    if [ -n "${OUTPUT:-}" ]; then
        printf '%s\n' "$OUTPUT"
    else
        error_exit "能碳诊断与报告交付程序执行失败"
    fi
    exit 1
}

if ! printf '%s' "$OUTPUT" | jq empty >/dev/null 2>&1; then
    error_exit "程序没有返回有效JSON"
fi

printf '%s\n' "$OUTPUT"
