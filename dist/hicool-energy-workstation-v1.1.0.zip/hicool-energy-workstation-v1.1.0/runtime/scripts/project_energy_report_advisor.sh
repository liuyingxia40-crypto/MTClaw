#!/bin/bash
set -euo pipefail

BASE_DIR="/data/energy-carbon-reports"

error_exit() {
    jq -n --arg error "$1" \
      '{"result":"error","tool":"project_energy_report_advisor","error":$error}'
    exit 1
}

INPUT=$(cat)

if ! jq empty <<<"$INPUT" >/dev/null 2>&1; then
    error_exit "输入不是有效JSON"
fi

PROJECT_QUERY=$(jq -r '.project_query | select(. != null)' <<<"$INPUT")
ACTION=$(jq -r '.action | select(. != null)' <<<"$INPUT")

[ -z "$PROJECT_QUERY" ] && error_exit "缺少project_query参数"
[ -z "$ACTION" ] && ACTION="analyze"

case "$ACTION" in
    find|summary|analyze) ;;
    *) error_exit "action只能是find、summary或analyze" ;;
esac

[ -d "$BASE_DIR" ] || error_exit "报告目录不存在：$BASE_DIR"

# 删除用户表达中的常见非项目名称词语，提高模糊匹配能力
KEYWORD=$(printf '%s' "$PROJECT_QUERY" |
    sed -E 's/[[:space:]]+//g; s/(项目|报告|能碳|诊断|最新|年度|请|帮我|调取|查看|分析)//g')

[ -z "$KEYWORD" ] && KEYWORD="$PROJECT_QUERY"

mapfile -t PDF_FILES < <(
    find "$BASE_DIR" -type f -iname "*.pdf" \
        -printf '%T@|%p\n' 2>/dev/null |
        sort -nr |
        cut -d'|' -f2-
)

[ "${#PDF_FILES[@]}" -eq 0 ] && error_exit "报告目录中没有PDF文件"

MATCHED_FILE=""

# 先匹配文件名，再匹配PDF前五页正文
for PDF_FILE in "${PDF_FILES[@]}"; do
    FILE_NAME=$(basename "$PDF_FILE")

    if printf '%s' "$FILE_NAME" | grep -qiF "$KEYWORD"; then
        MATCHED_FILE="$PDF_FILE"
        break
    fi

    TEMP_PREVIEW=$(mktemp)
    pdftotext -f 1 -l 5 -layout "$PDF_FILE" "$TEMP_PREVIEW" \
        2>/dev/null || true

    if grep -qiF "$KEYWORD" "$TEMP_PREVIEW"; then
        MATCHED_FILE="$PDF_FILE"
        rm -f "$TEMP_PREVIEW"
        break
    fi

    rm -f "$TEMP_PREVIEW"
done

if [ -z "$MATCHED_FILE" ]; then
    AVAILABLE_REPORTS=$(
        find "$BASE_DIR" -type f -iname "*.pdf" -printf '%f\n' |
        paste -sd '；' -
    )

    jq -n \
      --arg query "$PROJECT_QUERY" \
      --arg available "$AVAILABLE_REPORTS" \
      '{
        result:"not_found",
        tool:"project_energy_report_advisor",
        project_query:$query,
        message:"没有找到匹配的项目能碳报告",
        available_reports:$available
      }'
    exit 0
fi

FILE_NAME=$(basename "$MATCHED_FILE")
FILE_SIZE=$(du -h "$MATCHED_FILE" | awk '{print $1}')
MODIFIED_TIME=$(date -r "$MATCHED_FILE" '+%Y-%m-%d %H:%M:%S')
PAGES=$(pdfinfo "$MATCHED_FILE" 2>/dev/null |
    awk -F: '/^Pages/{gsub(/[[:space:]]/,"",$2); print $2}')

# 轻量模式：只返回报告元数据，不读取整份正文
if [ "$ACTION" = "find" ]; then
    jq -n \
      --arg query "$PROJECT_QUERY" \
      --arg file_name "$FILE_NAME" \
      --arg file_path "$MATCHED_FILE" \
      --arg file_size "$FILE_SIZE" \
      --arg modified_time "$MODIFIED_TIME" \
      --arg pages "${PAGES:-未知}" \
      '{
        result:"ok",
        tool:"project_energy_report_advisor",
        action:"find",
        project_query:$query,
        report:{
          file_name:$file_name,
          file_path:$file_path,
          file_size:$file_size,
          pages:$pages,
          modified_time:$modified_time
        },
        route_type:"lightweight_metadata"
      }'
    exit 0
fi

TEXT_FILE=$(mktemp)
trap 'rm -f "$TEXT_FILE"' EXIT

pdftotext -layout "$MATCHED_FILE" "$TEXT_FILE" 2>/dev/null ||
    error_exit "PDF正文提取失败"

if [ "$ACTION" = "summary" ]; then
    # 中等任务：只提取关键指标和结论附近内容
    EVIDENCE=$(
        grep -E -B2 -A8 \
          '执行摘要|关键指标|能源消费|碳排放|单位面积|排放来源|减排潜力|能源费用|数据质量' \
          "$TEXT_FILE" 2>/dev/null |
          awk '!seen[$0]++' |
          head -n 260 || true
    )

    INSTRUCTION="请只根据报告证据回答项目关键能耗、碳排放、碳强度、排放来源和减排潜力。不得编造报告中不存在的数据。"
    ROUTE_TYPE="targeted_report_summary"
else
    # 重型任务：组合执行摘要、问题、措施、投资回收期等相关证据
    BASIC_CONTENT=$(sed -n '1,220p' "$TEXT_FILE")

    RELATED_CONTENT=$(
        grep -E -B3 -A15 \
          '执行摘要|关键指标|能源消费|碳排放|重点问题|问题诊断|措施建议|实施路线|投资|回收期|减排潜力|数据质量' \
          "$TEXT_FILE" 2>/dev/null |
          awk '!seen[$0]++' |
          head -n 600 || true
    )

    EVIDENCE=$(
        printf '%s\n\n===== 报告重点证据 =====\n%s' \
          "$BASIC_CONTENT" "$RELATED_CONTENT" |
          python3 -c 'import sys; print(sys.stdin.read()[:15000])'
    )

    INSTRUCTION="请基于报告证据完成专业能碳诊断。依次输出：项目现状、主要问题、分级建议、每条建议的数据依据、预期节能减排效果、实施难度、优先级、报告未提供但仍需补充的数据。必须区分报告事实与模型判断，不得编造数字。"
    ROUTE_TYPE="deep_report_analysis"
fi

jq -n \
  --arg query "$PROJECT_QUERY" \
  --arg action "$ACTION" \
  --arg file_name "$FILE_NAME" \
  --arg file_path "$MATCHED_FILE" \
  --arg pages "${PAGES:-未知}" \
  --arg route_type "$ROUTE_TYPE" \
  --arg instruction "$INSTRUCTION" \
  --arg tool_output "$EVIDENCE" \
  '{
    result:"ok",
    tool:"project_energy_report_advisor",
    action:$action,
    project_query:$query,
    report:{
      file_name:$file_name,
      file_path:$file_path,
      pages:$pages
    },
    route_type:$route_type,
    needs_upstream_analysis:true,
    analysis_instruction:$instruction,
    tool_output:$tool_output
  }'
