#!/usr/bin/env bash
set -euo pipefail

PYTHON_FILE="$HOME/moor/MTClaw/vertical_subagents/carbon_asset_operations_subagent.py"

if [ "$#" -gt 0 ]; then
  exec python3 "$PYTHON_FILE" "$1"
else
  exec python3 "$PYTHON_FILE"
fi
