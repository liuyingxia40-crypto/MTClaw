#!/bin/bash
set -euo pipefail

PYTHON_FILE="$HOME/moor/MTClaw/vertical_subagents/energy_carbon_report_generator.py"

error_exit() {
    jq -n --arg error "$1" \
      '{
        "result":"error",
        "tool":"energy_carbon_report_generator",
        "error":$error
      }'
    exit 1
}

# 检查 Python 程序是否存在
if [ ! -f "$PYTHON_FILE" ]; then
    error_exit "找不到报告生成程序：$PYTHON_FILE"
fi

# 接收 Function Router 传入的 JSON
INPUT=$(cat)

# 检查输入是不是合法 JSON
if ! printf '%s' "$INPUT" | jq empty >/dev/null 2>&1; then
    error_exit "输入不是有效JSON"
fi

# 调用 Python 程序生成 PDF
OUTPUT=$(printf '%s' "$INPUT" | python3 "$PYTHON_FILE") || {
    printf '%s\n' "$OUTPUT"
    exit 1
}

# 检查程序返回内容
if ! printf '%s' "$OUTPUT" | jq empty >/dev/null 2>&1; then
    error_exit "报告生成程序没有返回有效JSON"
fi

printf '%s\n' "$OUTPUT"
