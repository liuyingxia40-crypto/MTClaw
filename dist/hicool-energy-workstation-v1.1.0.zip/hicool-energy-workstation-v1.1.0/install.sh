#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(
    cd "$(dirname "${BASH_SOURCE[0]}")"
    pwd
)"

BASE_DIR="${HICOOL_HOME:-$HOME/.local/share/hicool-energy-workstation}"
APP_DIR="$BASE_DIR/app"
DATA_DIR="$BASE_DIR/data"
VENV_DIR="$BASE_DIR/venv"
LOG_DIR="$BASE_DIR/logs"

FR_DIR="$HOME/.function-router"
OPENCLAW_DIR="$HOME/.openclaw"
LOCAL_BIN="$HOME/.local/bin"

for COMMAND in python3 openclaw curl; do
    if ! command -v "$COMMAND" >/dev/null 2>&1; then
        echo "❌ 缺少命令：$COMMAND"
        exit 1
    fi
done

API_KEY="${DEEPSEEK_API_KEY:-}"

if [ -z "$API_KEY" ]; then
    printf "请输入 DeepSeek API Key："
    read -r -s API_KEY
    echo
fi

if [ -z "$API_KEY" ]; then
    echo "❌ DeepSeek API Key不能为空"
    exit 1
fi

echo "===== 安装 HICOOL 能碳工作站 ====="

mkdir -p \
    "$BASE_DIR" \
    "$DATA_DIR" \
    "$LOG_DIR" \
    "$FR_DIR/scripts" \
    "$OPENCLAW_DIR" \
    "$LOCAL_BIN"

rm -rf "$APP_DIR"
mkdir -p "$APP_DIR"

cp -a "$PACKAGE_DIR/app/." "$APP_DIR/"
cp -a "$PACKAGE_DIR/sample_data/." "$DATA_DIR/"

# 兼容旧版Subagent内部路径
mkdir -p "$HOME/moor"
ln -sfn "$APP_DIR" "$HOME/moor/MTClaw"
cp -a "$PACKAGE_DIR/runtime/scripts/." "$FR_DIR/scripts/"

cp \
    "$PACKAGE_DIR/config/functions.jsonl" \
    "$FR_DIR/functions.jsonl"

rm -rf "$VENV_DIR" "$BASE_DIR/python-packages"

if python3 -m venv "$VENV_DIR" \
    >"$BASE_DIR/venv-create.log" 2>&1
then
    echo "Python运行方式：venv"

    "$VENV_DIR/bin/python" -m pip install \
        --upgrade pip setuptools wheel

    "$VENV_DIR/bin/python" -m pip install \
        -e "$APP_DIR"
else
    echo "⚠️ 当前系统无法创建标准venv，自动使用便携运行模式"
    rm -rf "$VENV_DIR"

    if ! python3 -m pip --version >/dev/null 2>&1
    then
        echo "❌ 当前系统同时缺少venv和pip"
        cat "$BASE_DIR/venv-create.log" || true
        exit 1
    fi

    PYTHON_VENDOR="$BASE_DIR/python-packages"
    SYSTEM_PYTHON="$(command -v python3)"

    mkdir -p "$VENV_DIR/bin" "$PYTHON_VENDOR"

    python3 -m pip install \
        --upgrade \
        --target "$PYTHON_VENDOR" \
        "$APP_DIR"

    cat > "$VENV_DIR/bin/python" <<EOF
#!/usr/bin/env bash
export PYTHONPATH="$PYTHON_VENDOR:$APP_DIR:\${PYTHONPATH:-}"
exec "$SYSTEM_PYTHON" "\$@"
EOF

    chmod +x "$VENV_DIR/bin/python"
    ln -sfn python "$VENV_DIR/bin/python3"

    echo "Python运行方式：便携pip target"
fi

export \
    APP_DIR \
    DATA_DIR \
    VENV_DIR \
    FR_DIR \
    API_KEY

"$VENV_DIR/bin/python" - <<'PY'
import json
import os
import re
from pathlib import Path

app_dir = os.environ["APP_DIR"]
data_dir = os.environ["DATA_DIR"]
fr_dir = os.environ["FR_DIR"]
api_key = os.environ["API_KEY"]

venv_python = str(
    Path(os.environ["VENV_DIR"])
    / "bin"
    / "python"
)

replacements = {
    "/root/moor/MTClaw": app_dir,
    "$HOME/moor/MTClaw": app_dir,
    "${HOME}/moor/MTClaw": app_dir,
    "~/moor/MTClaw": app_dir,
    "/root/.function-router": fr_dir,
    "/data/energy-ai":
        f"{data_dir}/energy-ai",
    "/data/energy-carbon-downloads":
        f"{data_dir}/energy-carbon-downloads",
    "/data/energy-carbon-projects":
        f"{data_dir}/energy-carbon-projects",
    "/data/energy-carbon-reports":
        f"{data_dir}/energy-carbon-reports",
    "http://8.130.125.178/reports/":
        "http://127.0.0.1:18888/",
}

suffixes = {
    ".py",
    ".sh",
    ".json",
    ".jsonl",
    ".js",
    ".ts",
    ".md",
    ".txt",
    ".toml",
}

for root in (
    Path(app_dir),
    Path(fr_dir) / "scripts",
):
    if not root.exists():
        continue

    for path in root.rglob("*"):
        if (
            not path.is_file()
            or path.suffix.lower()
            not in suffixes
        ):
            continue

        try:
            text = path.read_text(
                encoding="utf-8"
            )
        except UnicodeDecodeError:
            continue

        for old, new in replacements.items():
            text = text.replace(old, new)

        if path.suffix == ".sh":
            text = re.sub(
                r"(?m)^(\s*)(exec\s+)?python3(\s+)",
                rf'\1\2"{venv_python}"\3',
                text,
            )

        path.write_text(
            text,
            encoding="utf-8",
        )

config = {
    "listen_host": "127.0.0.1",
    "listen_port": 18790,
    "tools_base_dir":
        f"{fr_dir}/scripts",
    "fr_completion_check": {
        "enabled": True,
        "mode": "permissive",
        "always_true": False,
    },
    "fr_context_history": {
        "enabled": True,
    },
    "fr_context_preserve": {
        "enabled": False,
    },
    "delegate_tools_to_openclaw": {
        "enabled": True,
    },
    "routing": {
        "base_url":
            "https://api.deepseek.com",
        "model":
            "deepseek-v4-flash",
        "api_key":
            api_key,
    },
    "upstream": {
        "base_url":
            "https://api.deepseek.com",
        "model":
            "deepseek-v4-pro",
        "api_key":
            api_key,
    },
    "functions_file":
        "functions.jsonl",
    "scripts_dir":
        "scripts",
    "max_tool_rounds":
        6,
    "tool_exec_timeout_s":
        30,
    "routing_timeout_s":
        30.0,
    "debug_logging": {
        "enabled": False,
    },
}

config_path = (
    Path(fr_dir)
    / "config.json"
)

config_path.write_text(
    json.dumps(
        config,
        ensure_ascii=False,
        indent=2,
    )
    + "\n",
    encoding="utf-8",
)
PY

chmod +x "$FR_DIR/scripts/"*.sh 2>/dev/null || true

cp \
    "$PACKAGE_DIR/bin/hicool-energy" \
    "$BASE_DIR/hicool-energy"

chmod +x "$BASE_DIR/hicool-energy"

ln -sfn \
    "$BASE_DIR/hicool-energy" \
    "$LOCAL_BIN/hicool-energy"

python3 - <<'PY'
import json
import secrets
from pathlib import Path

path = (
    Path.home()
    / ".openclaw"
    / "openclaw.json"
)

if path.exists():
    try:
        data = json.loads(
            path.read_text(
                encoding="utf-8"
            )
        )
    except Exception:
        data = {}
else:
    data = {}

providers = (
    data
    .setdefault("models", {})
    .setdefault("providers", {})
)

providers["function_router"] = {
    "baseUrl":
        "http://127.0.0.1:18790/v1",
    "apiKey":
        "function-router-local",
    "api":
        "openai-completions",
    "models": [
        {
            "id": "function-router",
            "name": "Function Router",
        }
    ],
}

data.setdefault(
    "agents",
    {},
).setdefault(
    "defaults",
    {},
).setdefault(
    "model",
    {},
)["primary"] = (
    "function_router/function-router"
)

gateway = data.setdefault(
    "gateway",
    {},
)

gateway["mode"] = "local"

auth = gateway.setdefault(
    "auth",
    {},
)

auth.setdefault("mode", "token")
auth.setdefault(
    "token",
    secrets.token_hex(24),
)

path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

path.write_text(
    json.dumps(
        data,
        ensure_ascii=False,
        indent=2,
    )
    + "\n",
    encoding="utf-8",
)
PY

echo
echo "✅ 安装完成"
echo "安装目录：$BASE_DIR"
echo "启动命令：$LOCAL_BIN/hicool-energy"
echo

"$BASE_DIR/hicool-energy" start
"$BASE_DIR/hicool-energy" status
