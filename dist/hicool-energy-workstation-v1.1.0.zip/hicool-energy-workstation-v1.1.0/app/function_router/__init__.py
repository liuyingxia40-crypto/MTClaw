"""OpenClaw Function Router package."""

from .server import main

__version__ = "1.0.0"

__all__ = ["__version__", "main"]
